import React, { useState } from 'react'
import RatingStars from './RatingStars'
import { reviewsService } from '../services/reviews'

export default function ReviewForm({ eventId, userId, onReviewSubmitted, existingReview = null }) {
  const [rating, setRating] = useState(existingReview?.rating || 0)
  const [comment, setComment] = useState(existingReview?.comment || '')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (rating === 0) {
      setMessage('Please select a rating')
      return
    }

    setLoading(true)
    setMessage('')

    try {
      let result
      if (existingReview?.review_id) {
        result = await reviewsService.updateReview(
          existingReview.review_id,
          rating,
          comment
        )
      } else {
        result = await reviewsService.addReview(userId, eventId, rating, comment)
      }

      if (result.success) {
        setMessage('✓ Review submitted successfully!')
        setRating(0)
        setComment('')
        setTimeout(() => {
          onReviewSubmitted()
        }, 1000)
      } else {
        setMessage(`Error: ${result.error}`)
      }
    } catch (error) {
      setMessage('Failed to submit review')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async () => {
    if (!window.confirm('Delete this review?')) return

    setLoading(true)
    try {
      const result = await reviewsService.deleteReview(existingReview.review_id)
      if (result.success) {
        setMessage('✓ Review deleted successfully!')
        setTimeout(() => {
          onReviewSubmitted()
        }, 1000)
      } else {
        setMessage(`Error: ${result.error}`)
      }
    } catch (error) {
      setMessage('Failed to delete review')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="bg-gray-800 p-6 rounded-xl mb-6">
      <h3 className="text-xl font-bold mb-4">
        {existingReview ? 'Edit Your Review' : 'Write a Review'}
      </h3>

      {message && (
        <div className={`mb-4 p-3 rounded-lg text-center ${message.includes('✓') ? 'bg-green-900 text-green-200' : 'bg-red-900 text-red-200'}`}>
          {message}
        </div>
      )}

      <div className="mb-4">
        <label className="block text-gray-300 mb-2">Rating</label>
        <div onClick={() => setRating(0)} className="cursor-pointer">
          <RatingStars 
            rating={rating} 
            size="lg"
            interactive={true}
            onRate={setRating}
          />
        </div>
      </div>

      <div className="mb-4">
        <label className="block text-gray-300 mb-2">Comment (Optional)</label>
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          maxLength={500}
          placeholder="Share your experience..."
          className="w-full px-4 py-2 bg-gray-700 text-white rounded-lg border border-gray-600 focus:outline-none focus:border-purple-500 resize-none"
          rows="4"
        />
        <p className="text-gray-400 text-sm mt-1">{comment.length}/500</p>
      </div>

      <div className="flex gap-3">
        <button
          type="submit"
          disabled={loading}
          className="flex-1 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white py-2 rounded-lg font-semibold transition"
        >
          {loading ? '⏳ Submitting...' : (existingReview ? 'Update Review' : 'Submit Review')}
        </button>
        {existingReview && (
          <button
            type="button"
            onClick={handleDelete}
            disabled={loading}
            className="px-6 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white py-2 rounded-lg font-semibold transition"
          >
            Delete
          </button>
        )}
      </div>
    </form>
  )
}
