import React from 'react'

export default function RatingStars({ rating, size = 'md', interactive = false, onRate = null }) {
  const sizeClasses = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-4xl'
  }

  const handleRate = (value) => {
    if (interactive && onRate) {
      onRate(value)
    }
  }

  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          onClick={() => handleRate(star)}
          disabled={!interactive}
          className={`${sizeClasses[size]} ${
            star <= Math.round(rating)
              ? 'text-yellow-400'
              : 'text-gray-600'
          } transition ${interactive ? 'cursor-pointer hover:scale-110' : 'cursor-default'}`}
        >
          ★
        </button>
      ))}
    </div>
  )
}
