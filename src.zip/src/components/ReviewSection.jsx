import React from 'react'
import RatingStars from './RatingStars'

export default function ReviewSection({ reviews, averageRating, totalReviews, showForm }) {
  return (
    <div className="bg-gray-900 p-6 rounded-2xl mb-6">
      <h3 className="text-2xl font-bold mb-6">Reviews & Ratings</h3>

      {/* Rating Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 pb-8 border-b border-gray-700">
        <div className="text-center">
          <div className="text-5xl font-bold text-yellow-400 mb-2">{averageRating}</div>
          <RatingStars rating={averageRating} size="md" />
          <p className="text-gray-400 mt-2">{totalReviews} reviews</p>
        </div>

        {/* Rating Distribution */}
        <div className="md:col-span-2 space-y-2">
          {[5, 4, 3, 2, 1].map((stars) => {
            const count = reviews.filter(r => r.rating === stars).length
            const percentage = totalReviews > 0 ? (count / totalReviews) * 100 : 0
            return (
              <div key={stars} className="flex items-center gap-3">
                <span className="text-gray-400 text-sm min-w-8">{stars}★</span>
                <div className="flex-1 bg-gray-800 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-yellow-400 h-full transition-all"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
                <span className="text-gray-400 text-sm min-w-8">{count}</span>
              </div>
            )
          })}
        </div>
      </div>

      {/* Review Form */}
      {showForm && showForm}

      {/* Reviews List */}
      <div>
        <h4 className="text-lg font-bold mb-4">
          {reviews.length > 0 ? `All Reviews (${reviews.length})` : 'No reviews yet'}
        </h4>

        <div className="space-y-4">
          {reviews.map((review) => (
            <div key={review.review_id} className="bg-gray-800 p-4 rounded-lg">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="font-semibold text-white">
                    {review.users?.name || 'Anonymous'}
                  </p>
                  <p className="text-gray-400 text-sm">
                    {new Date(review.created_at).toLocaleDateString()}
                  </p>
                </div>
                <RatingStars rating={review.rating} size="sm" />
              </div>

              {review.comment && (
                <p className="text-gray-300 text-sm mt-2">{review.comment}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
