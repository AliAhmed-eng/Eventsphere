import { Link } from 'react-router-dom'
import { useState, useEffect } from 'react'

function Navbar({ onLogout }) {
  const [cartCount, setCartCount] = useState(0)
  const [wishlistCount, setWishlistCount] = useState(0)
  const [userId, setUserId] = useState(null)

  useEffect(() => {
    const id = localStorage.getItem('user_id')
    setUserId(id)
    updateCounts(id)
    
    window.addEventListener('storage', () => updateCounts(id))
    window.addEventListener('cartUpdated', () => updateCounts(id))
    window.addEventListener('wishlistUpdated', () => updateCounts(id))
    
    return () => {
      window.removeEventListener('storage', () => updateCounts(id))
      window.removeEventListener('cartUpdated', () => updateCounts(id))
      window.removeEventListener('wishlistUpdated', () => updateCounts(id))
    }
  }, [])

  const updateCounts = async (id) => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]')
    setCartCount(cart.length)

    if (id) {
      const wishlistKey = `wishlist_${id}`
      const wishlist = JSON.parse(localStorage.getItem(wishlistKey) || '[]')
      setWishlistCount(wishlist.length)
    }
  }

  return (
    <nav className='bg-black text-white px-8 py-4 flex justify-between items-center shadow-sm sticky top-0 z-50'>
      <Link to='/' className='text-5xl font-extrabold text-cyan-400 hover:text-cyan-300 transition'>
        EventSphere
      </Link>

      <div className='space-x-6 text-lg font-medium flex items-center'>
        <Link className='hover:text-cyan-400 transition' to='/'>Home</Link>
        <Link className='hover:text-cyan-400 transition' to='/events'>Events</Link>
        <Link className='hover:text-cyan-400 transition' to='/dashboard'>Dashboard</Link>
        <Link className='hover:text-cyan-400 transition' to='/wishlist'>Wishlist</Link>
        <Link className='hover:text-cyan-400 transition' to='/cart'>Cart</Link>
        <Link className='hover:text-cyan-400 transition' to='/my-bookings'>My Bookings</Link>

        {onLogout && (
          <button 
            onClick={onLogout}
            className='ml-4 bg-red-600 hover:bg-red-700 px-3 py-1 rounded-md text-sm transition'
          >
            Logout
          </button>
        )}
      </div>
    </nav>
  )
}

export default Navbar