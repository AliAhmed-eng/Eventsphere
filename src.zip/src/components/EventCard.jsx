import { Link } from "react-router-dom";
import { useState, useEffect } from "react";

function EventCard({ event, onBook }) {
  const [rating, setRating] = useState(0);
  const [reviewCount, setReviewCount] = useState(0);

  useEffect(() => {
    if (event?.reviews) {
      const totalReviews = event.reviews.length;
      const avgRating =
        totalReviews > 0
          ? (event.reviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews).toFixed(1)
          : 0;
      setRating(parseFloat(avgRating));
      setReviewCount(totalReviews);
    }
  }, [event]);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  const seatStatus =
    event?.available_seats === 0
      ? "Sold Out"
      : event?.available_seats <= 5
      ? `Only ${event?.available_seats} left`
      : `${event?.available_seats} seats available`;

  return (
    <div className="group bg-white/10 backdrop-blur-md rounded-xl border border-white/20 hover:border-purple-500/50 overflow-hidden transition duration-300 hover:shadow-xl hover:shadow-purple-500/20 transform hover:scale-105">
      {/* Image */}
      <div className="relative h-48 bg-gradient-to-br from-purple-600 to-blue-600 overflow-hidden">
        {event?.image_url ? (
          <img
            src={event.image_url}
            alt={event.title}
            className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-4xl">🎭</div>
        )}
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition duration-300"></div>
        {/* Price Badge */}
        <div className="absolute top-3 right-3 bg-gradient-to-r from-purple-500 to-blue-500 px-3 py-1 rounded-full text-white font-bold text-sm">
          ${event?.price}
        </div>
        {/* Rating */}
        <div className="absolute bottom-3 right-3 bg-black/70 px-3 py-1 rounded-full text-white text-sm">
          ⭐ {rating} ({reviewCount})
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        {/* Title */}
        <Link to={`/event/${event?.event_id}`}>
          <h3 className="text-lg font-bold text-white mb-2 group-hover:text-purple-400 transition cursor-pointer line-clamp-2">
            {event?.title}
          </h3>
        </Link>

        {/* Venue */}
        <div className="flex items-center space-x-2 text-sm text-gray-300 mb-3">
          <span>📍</span>
          <p className="truncate">{event?.venue}</p>
        </div>

        {/* Date */}
        <div className="flex items-center space-x-2 text-sm text-gray-300 mb-3">
          <span>📅</span>
          <p>{formatDate(event?.event_date)}</p>
        </div>

        {/* Category Tags */}
        {event?.event_categories && event.event_categories.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-3">
            {event.event_categories.slice(0, 2).map((cat) => (
              <span
                key={cat.category_id}
                className="text-xs bg-purple-500/30 text-purple-200 px-2 py-1 rounded-full border border-purple-400/30"
              >
                {cat.categories?.name || cat.category_id}
              </span>
            ))}
          </div>
        )}

        {/* Seat Status */}
        <div className="mb-3">
          <p
            className={`text-xs font-semibold ${
              event?.available_seats === 0 ? "text-red-400" : "text-green-400"
            }`}
          >
            {seatStatus}
          </p>
        </div>

        {/* Book Button */}
        <button
          onClick={() => onBook?.(event)}
          disabled={event?.available_seats === 0}
          className="w-full px-4 py-2 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 disabled:from-gray-600 disabled:to-gray-600 text-white font-semibold rounded-lg transition duration-300 transform hover:scale-105 active:scale-95"
        >
          {event?.available_seats === 0 ? "Sold Out" : "Book Now"}
        </button>
      </div>
    </div>
  );
}

export default EventCard;