import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import LoadingSpinner from '../components/LoadingSpinner'
import { getBookingById } from '../services/bookings'

function BookingConfirmation() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [booking, setBooking] = useState(null)
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState(null)

  useEffect(() => {
    const userData = localStorage.getItem('user')
    if (userData) {
      setUser(JSON.parse(userData))
    }
    fetchBookingDetails()
  }, [id])

  async function fetchBookingDetails() {
    try {
      const data = await getBookingById(parseInt(id))
      setBooking(data)
    } catch (error) {
      console.error('Error fetching booking:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  if (loading) {
    return (
      <div className="bg-gray-950 min-h-screen text-white">
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <LoadingSpinner />
        </div>
        <Footer />
      </div>
    )
  }

  if (!booking) {
    return (
      <div className="bg-gray-950 min-h-screen text-white">
        <Navbar />
        <div className="px-10 py-20 text-center">
          <h1 className="text-4xl font-bold mb-4">Booking Not Found</h1>
          <p className="text-gray-400 mb-8">The booking you're looking for doesn't exist.</p>
          <button
            onClick={() => navigate('/events')}
            className="px-6 py-3 bg-purple-600 rounded-lg hover:bg-purple-700 transition"
          >
            Browse Events
          </button>
        </div>
        <Footer />
      </div>
    )
  }

  const numTickets = booking.quantity || 1
  const event = booking.events
  const totalPrice = event?.price ? event.price * numTickets : 0

  return (
    <div className="bg-gray-950 min-h-screen text-white">
      <Navbar />

      <div className="px-10 py-10">
        {/* Success Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-500/20 rounded-full mb-6">
            <svg className="w-10 h-10 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="text-4xl font-bold mb-2">Booking Confirmed!</h1>
          <p className="text-gray-400">Your tickets have been successfully booked</p>
        </div>

        {/* Booking Details Card */}
        <div className="max-w-3xl mx-auto">
          <div className="bg-gray-900 rounded-2xl p-8 mb-8 border border-white/10">
            <div className="flex justify-between items-start mb-6">
              <div>
                <p className="text-gray-400 text-sm mb-1">Booking ID</p>
                <p className="text-2xl font-bold">#{booking.booking_id}</p>
              </div>
              <div className="text-right">
                <p className="text-gray-400 text-sm mb-1">Booking Date</p>
                <p className="text-lg">{formatDate(booking.booking_date)}</p>
              </div>
            </div>

            <div className="border-t border-gray-800 pt-6">
              <h2 className="text-2xl font-bold mb-4">{event?.title}</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-400">📍</span>
                    <div>
                      <p className="text-gray-400 text-sm">Venue</p>
                      <p className="font-semibold">{event?.venue}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-400">📅</span>
                    <div>
                      <p className="text-gray-400 text-sm">Date</p>
                      <p className="font-semibold">{event?.event_date}</p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-400">🎫</span>
                    <div>
                      <p className="text-gray-400 text-sm">Tickets</p>
                      <p className="font-semibold">{numTickets} ticket{numTickets > 1 ? 's' : ''}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-400">💰</span>
                    <div>
                      <p className="text-gray-400 text-sm">Total Price</p>
                      <p className="font-semibold text-purple-400">Rs. {totalPrice}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* User Info */}
            {user && (
              <div className="border-t border-gray-800 pt-6 mt-6">
                <h3 className="text-lg font-semibold mb-3">Attendee Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-400 text-sm">Name</p>
                    <p className="font-semibold">{user.name || user.email}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Email</p>
                    <p className="font-semibold">{user.email}</p>
                  </div>
                  {user.phone && (
                    <div>
                      <p className="text-gray-400 text-sm">Phone</p>
                      <p className="font-semibold">{user.phone}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => window.print()}
              className="px-6 py-3 bg-gray-800 rounded-lg hover:bg-gray-700 transition flex items-center justify-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 17V7a2 2 0 012-2h6a2 2 0 012 2v10m-8 0h8" />
              </svg>
              Print Ticket
            </button>
            <button
              onClick={() => navigate('/my-bookings')}
              className="px-6 py-3 bg-purple-600 rounded-lg hover:bg-purple-700 transition"
            >
              View My Bookings
            </button>
            <button
              onClick={() => navigate('/events')}
              className="px-6 py-3 bg-gray-800 rounded-lg hover:bg-gray-700 transition"
            >
              Browse More Events
            </button>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}

export default BookingConfirmation