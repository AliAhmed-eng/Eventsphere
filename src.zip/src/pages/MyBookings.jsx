import { useState, useEffect } from "react";
import Sidebar from "../components/Sidebar";
import LoadingSpinner from "../components/LoadingSpinner";
import Toast from "../components/Toast";
import { getUserBookings, cancelBooking } from "../services/bookings";
import { useAuth } from "../hooks/useAuth";

function MyBookings() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    fetchBookings();
  }, [user]);

  const fetchBookings = async () => {
    if (!user) return;
    setLoading(true);
    const data = await getUserBookings(user.user_id);
    setBookings(data);
    setLoading(false);
  };

  const handleCancelBooking = async (bookingId, eventId, quantity) => {
    const { success, error } = await cancelBooking(bookingId, eventId, quantity);

    if (error) {
      setToast({ message: error, type: "error" });
      return;
    }

    setToast({ message: "Booking cancelled successfully", type: "success" });
    fetchBookings();
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="flex h-screen bg-linear-to-br from-slate-900 via-purple-900 to-slate-900">
      <Sidebar />

      <main className="flex-1 md:ml-64 overflow-auto">
        <div className="p-8">
          {/* Header */}
          <div className="mb-12">
            <h1 className="text-4xl font-bold text-white mb-2">My Bookings</h1>
            <p className="text-gray-400">View and manage your event bookings</p>
          </div>

          {/* Bookings List */}
          {bookings.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-400 text-lg mb-4">No bookings yet</p>
              <p className="text-gray-500">Start exploring events and book your tickets!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {bookings.map((booking) => {
                const numTickets = booking.quantity || 1;
                const event = booking.events;
                const totalPrice = event?.price ? event.price * numTickets : 0;

                return (
                  <div
                    key={booking.booking_id}
                    className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-6 hover:border-purple-500/50 transition"
                  >
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
                      {/* Booking Info */}
                      <div className="flex-1">
                        <h3 className="text-2xl font-bold text-white mb-2">
                          {event?.title}
                        </h3>

                        <div className="space-y-2 text-gray-300">
                          <div className="flex items-center space-x-2">
                            <span>📍</span>
                            <p>{event?.venue}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span>📅</span>
                            <p>{formatDate(event?.event_date)}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span>🎫</span>
                            <p>{numTickets} ticket{numTickets > 1 ? "s" : ""}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span>💳</span>
                            <p>Rs. {totalPrice}</p>
                          </div>
                        </div>

                        {/* Booking ID */}
                        <div className="mt-4">
                          <span className="text-sm text-gray-500">
                            Booking ID: #{booking.booking_id}
                          </span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex flex-col gap-2">
                        <button
                            onClick={() =>
                            handleCancelBooking(
                              booking.booking_id,
                              booking.event_id,
                              numTickets
                            )
                          }
                          className="px-6 py-2 bg-red-500/20 hover:bg-red-500/30 border border-red-500/50 text-red-300 rounded-lg transition"
                        >
                          Cancel Booking
                        </button>
                        <button 
                          onClick={() => alert('Booking details feature coming soon!')}
                          className="px-6 py-2 bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/50 text-purple-300 rounded-lg transition"
                        >
                          View Details
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>

      {/* Toast */}
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}

export default MyBookings;