import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import ReviewSection from '../components/ReviewSection'
import ReviewForm from '../components/ReviewForm'
import RatingStars from '../components/RatingStars'
import { supabase } from '../services/supabase'
import { reviewsService } from '../services/reviews'
import { categoriesService } from '../services/categories'
import { organizersService } from '../services/organizers'
import { createBooking } from '../services/bookings'

function EventDetail() {
  const { id } = useParams()
  const navigate = useNavigate()

  const [event, setEvent] = useState(null)
  const [relatedEvents, setRelatedEvents] = useState([])
  const [quantity, setQuantity] = useState(1)
  const [showBookingModal, setShowBookingModal] = useState(false)
  const [loading, setLoading] = useState(true)
  const [bookingLoading, setBookingLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [userId, setUserId] = useState(null)
  const [reviews, setReviews] = useState([])
  const [averageRating, setAverageRating] = useState(0)
  const [totalReviews, setTotalReviews] = useState(0)
  const [userReview, setUserReview] = useState(null)
  const [categories, setCategories] = useState([])
  const [organizers, setOrganizers] = useState([])

  useEffect(() => {
    const storedUserId = localStorage.getItem('user_id')
    setUserId(storedUserId)

    fetchEventDetail()
  }, [id])

  async function fetchEventDetail() {
    try {
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .eq('event_id', parseInt(id))
        .single()

      if (!error && data) {
        setEvent(data)
        fetchRelatedEvents(data.venue)
        fetchCategories(data.event_id)
        fetchOrganizers(data.event_id)
        fetchReviews(data.event_id)

        const u = localStorage.getItem('user_id')
        if (u) {
          checkUserReview(u, data.event_id)
        }
      }
    } catch (error) {
      console.error('Error fetching event:', error)
    } finally {
      setLoading(false)
    }
  }

  async function fetchRelatedEvents(venue) {
    try {
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .eq('venue', venue)
        .neq('event_id', parseInt(id))
        .limit(3)

      if (!error) {
        setRelatedEvents(data || [])
      }
    } catch (error) {
      console.error('Error fetching related events:', error)
    }
  }

  async function fetchCategories(eventId) {
    const data = await categoriesService.getEventCategories(eventId)
    setCategories(data || [])
  }

  async function fetchOrganizers(eventId) {
    const data = await organizersService.getEventOrganizers(eventId)
    setOrganizers(data || [])
  }

  async function fetchReviews(eventId) {
    const data = await reviewsService.getEventReviews(eventId)
    setReviews(data || [])

    const ratingData = await reviewsService.getEventRating(eventId)
    setAverageRating(ratingData?.averageRating || 0)
    setTotalReviews(ratingData?.totalReviews || 0)
  }

  async function checkUserReview(userId, eventId) {
    const review = await reviewsService.getUserReview(
      parseInt(userId),
      parseInt(eventId)
    )
    setUserReview(review)
  }

  const handleBooking = async () => {
    setBookingLoading(true)
    setMessage('')

    try {
      const userId = localStorage.getItem('user_id')


      if (!userId) {
        setMessage('✗ Please login first')
        return
      }

      const { booking, error } = await createBooking({
        user_id: parseInt(userId),
        event_id: parseInt(id),
        quantity: quantity
      })

      if (error) {
        setMessage(`✗ ${error}`)
        return
      }

      const cart = JSON.parse(localStorage.getItem('cart') || '[]')
      const updatedCart = cart.filter(
        item => item.event_id !== parseInt(id)
      )
      localStorage.setItem('cart', JSON.stringify(updatedCart))

      setMessage(`✓ ${quantity} booking(s) successful! Booking ID: #${booking.booking_id}`)
      setQuantity(1)

      window.dispatchEvent(new Event('cartUpdated'))

      setTimeout(() => {
        navigate(`/booking-confirmation/${booking.booking_id}`)
      }, 1200)

    } catch (error) {
      console.error(error)
      setMessage('Booking failed. Try again.')
    } finally {
      setBookingLoading(false)
    }
  }

  const handleOpenBookingModal = () => {
    setShowBookingModal(true)
  }

  const handleAddToWishlistLocal = () => {
    const id = localStorage.getItem('user_id') || '1'
    const wishlistKey = `wishlist_${id}`
    const wishlist = JSON.parse(localStorage.getItem(wishlistKey) || '[]')
    const exists = wishlist.some(i => i.event_id === event.event_id)
    if (!exists) {
      wishlist.push({ wishlist_id: Date.now(), event_id: event.event_id, events: event })
      localStorage.setItem(wishlistKey, JSON.stringify(wishlist))
      window.dispatchEvent(new Event('wishlistUpdated'))
      setMessage('✓ Added to wishlist')
      setTimeout(() => setMessage(''), 2000)
    } else {
      setMessage('Already in wishlist')
      setTimeout(() => setMessage(''), 2000)
    }
  }

  const handleAddToCartLocal = () => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]')
    const exists = cart.some(c => c.event_id === event.event_id)
    if (!exists) {
      cart.push({ ...event, event_id: event.event_id, quantity: quantity })
      localStorage.setItem('cart', JSON.stringify(cart))
      window.dispatchEvent(new Event('cartUpdated'))
      setMessage('✓ Added to cart')
      setTimeout(() => setMessage(''), 2000)
    } else {
      setMessage('Already in cart')
      setTimeout(() => setMessage(''), 2000)
    }
  }

  const shareOnSocial = (platform) => {
    const text = `Check out this awesome event: ${event?.title} at ${event?.venue}`

    const links = {
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${window.location.href}`,
      whatsapp: `https://wa.me/?text=${encodeURIComponent(text)}`
    }

    window.open(links[platform], '_blank')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 text-white flex items-center justify-center">
        <Navbar />
        <p className="text-xl">Loading...</p>
      </div>
    )
  }

  if (!event) {
    return (
      <div className="min-h-screen bg-gray-950 text-white">
        <Navbar />
        <div className="text-center p-10">
          <p className="text-2xl">Event not found</p>
          <button
            onClick={() => navigate('/events')}
            className="mt-4 px-6 py-2 bg-purple-600 rounded-lg"
          >
            Back
          </button>
        </div>
        <Footer />
      </div>
    )
  }

  const totalPrice = event.price * quantity

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Navbar />

      <div className="px-10 py-10">

        <button
          onClick={() => navigate('/events')}
          className="mb-6 px-4 py-2 bg-purple-600 rounded-lg"
        >
          ← Back
        </button>

        <h1 className="text-4xl font-bold mb-4">{event.title}</h1>

        <div className="bg-gray-900 p-6 rounded-xl mb-6">
          <p>Venue: {event.venue}</p>
          <p>Date: {event.event_date}</p>
          <p>Price: Rs {event.price}</p>
          <p>Seats: {event.available_seats}</p>
        </div>

        <div className="mb-6">
          <button
            onClick={handleOpenBookingModal}
            disabled={bookingLoading}
            className="bg-purple-600 px-6 py-3 rounded-lg"
          >
            {bookingLoading ? 'Booking...' : `Book ${quantity}`}
          </button>
        </div>

        {message && (
          <p className="mb-4 text-yellow-400">{message}</p>
        )}

        <ReviewSection
          reviews={reviews}
          averageRating={averageRating}
          totalReviews={totalReviews}
          showForm={
            userId ? (
              <ReviewForm
                eventId={parseInt(id)}
                userId={parseInt(userId)}
                existingReview={userReview}
                onReviewSubmitted={() => {
                  fetchReviews(parseInt(id))
                  checkUserReview(userId, parseInt(id))
                }}
              />
            ) : (
              <p>Please login to review</p>
            )
          }
        />

      </div>

      {showBookingModal && (
        <BookingModal
          event={event}
          quantity={quantity}
          setQuantity={setQuantity}
          onClose={() => setShowBookingModal(false)}
          onBook={async () => {
            await handleBooking()
            setShowBookingModal(false)
          }}
          onAddToWishlist={() => handleAddToWishlistLocal()}
          onAddToCart={() => handleAddToCartLocal()}
          loading={bookingLoading}
        />
      )}
      <Footer />
    </div>
  )
}

// Booking Modal (keeps dark glassmorphism style)
function BookingModal({ event, quantity, setQuantity, onClose, onBook, onAddToWishlist, onAddToCart, loading }) {
  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-2xl p-6 max-w-2xl w-full border border-white/10">
        <div className="flex gap-4">
          {event?.image_url && (
            <img src={event.image_url} alt={event.title} className="w-40 h-28 object-cover rounded-lg" />
          )}
          <div className="flex-1">
            <h3 className="text-2xl font-bold">{event?.title}</h3>
            <p className="text-gray-400 text-sm mb-2">{event?.venue} • {event?.event_date}</p>
            <p className="text-gray-300 mb-3">{event?.description}</p>
            <p className="text-purple-400 text-xl font-bold mb-3">Rs. {event?.price}</p>

            <div className="flex items-center gap-3 mb-4">
              <label className="text-gray-400">Tickets</label>
              <input
                type="number"
                min="1"
                max={event?.available_seats || 1}
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-20 px-3 py-2 bg-white/5 rounded-lg text-white"
              />
            </div>

            <div className="flex gap-3">
              <button onClick={onBook} className="px-4 py-2 bg-purple-600 rounded-lg">{loading ? 'Booking...' : 'Book Now'}</button>
              <button onClick={onAddToWishlist} className="px-4 py-2 bg-gray-800 rounded-lg">Add to Wishlist</button>
              <button onClick={onAddToCart} className="px-4 py-2 bg-green-600 rounded-lg">Add to Cart</button>
              <button onClick={onClose} className="ml-auto px-3 py-2 bg-white/5 rounded-lg">Close</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default EventDetail