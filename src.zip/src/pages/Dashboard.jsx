import { useState, useEffect } from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import EventCard from "../components/EventCard";
import LoadingSpinner from "../components/LoadingSpinner";
import Toast from "../components/Toast";
import { getAllEvents } from "../services/events";
import { createBooking } from "../services/bookings";
import { useAuth } from "../hooks/useAuth";

function Dashboard() {
  const { user } = useAuth();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState(null);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [bookingData, setBookingData] = useState({ numTickets: 1 });

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    setLoading(true);
    const data = await getAllEvents();
    setEvents(data);
    setLoading(false);
  };

  const handleBook = (event) => {
    setSelectedEvent(event);
    setShowBookingModal(true);
  };

  const handleConfirmBooking = async () => {
    if (!user) {
      setToast({ message: "Please log in to book events", type: "error" });
      return;
    }

    const { booking, error } = await createBooking({
      user_id: user.user_id,
      event_id: selectedEvent.event_id,
      quantity: bookingData.numTickets
    });

    if (error) {
      setToast({ message: error, type: "error" });
      return;
    }

    setToast({ message: "Booking successful! Check your bookings.", type: "success" });
    setShowBookingModal(false);
    setBookingData({ numTickets: 1 });
    fetchEvents();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 text-white">
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <LoadingSpinner />
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Navbar />

      <div className="px-6 py-10 max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold">Welcome{user?.name ? `, ${user.name}` : ''}!</h1>
          <p className="text-gray-400">Discover and book amazing events</p>
        </div>

        <section>
          <h2 className="text-2xl font-bold text-white mb-6">Upcoming Events</h2>
          {events.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-400 text-lg">No events found</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {events.map((event) => (
                <EventCard key={event.event_id} event={event} onBook={handleBook} />
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Booking Modal */}
      {showBookingModal && selectedEvent && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-gradient-to-b from-slate-800 to-slate-900 rounded-2xl p-8 max-w-md w-full border border-white/20">
            <h2 className="text-2xl font-bold text-white mb-4">Confirm Booking</h2>

            <div className="space-y-4 mb-6">
              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm">Event</p>
                <p className="text-white font-semibold">{selectedEvent.title}</p>
              </div>

              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm">Price per ticket</p>
                <p className="text-white font-semibold">${selectedEvent.price}</p>
              </div>

              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm mb-2">Number of Tickets</p>
                <input
                  type="number"
                  min="1"
                  max={selectedEvent.available_seats}
                  value={bookingData.numTickets}
                  onChange={(e) =>
                    setBookingData({ numTickets: Math.min(parseInt(e.target.value) || 1, selectedEvent.available_seats) })
                  }
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
                />
              </div>

              <div className="bg-gradient-to-r from-purple-500/20 to-blue-500/20 p-4 rounded-lg border border-purple-500/50">
                <p className="text-gray-400 text-sm">Total</p>
                <p className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400">
                  ${selectedEvent.price * bookingData.numTickets}
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowBookingModal(false);
                  setBookingData({ numTickets: 1 });
                }}
                className="flex-1 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmBooking}
                className="flex-1 px-4 py-2 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white font-semibold rounded-lg transition"
              >
                Confirm Booking
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
      <Footer />
    </div>
  );
}

export default Dashboard;