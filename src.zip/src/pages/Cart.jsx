import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import { getOrCreateUser } from '../services/auth'
import { createBooking } from '../services/bookings'

function Cart() {
  const [cartItems, setCartItems] = useState([])
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const navigate = useNavigate()

  useEffect(() => {
    loadCart()
    
    // Listen for cart updates
    window.addEventListener('cartUpdated', loadCart)
    window.addEventListener('storage', loadCart)
    
    return () => {
      window.removeEventListener('cartUpdated', loadCart)
      window.removeEventListener('storage', loadCart)
    }
  }, [])

  const loadCart = () => {
    const saved = localStorage.getItem('cart')
    if (saved) {
      setCartItems(JSON.parse(saved))
    } else {
      setCartItems([])
    }
  }

  const handleRemoveFromCart = (eventId) => {
    const updated = cartItems.filter(item => item.event_id !== eventId)
    setCartItems(updated)
    localStorage.setItem('cart', JSON.stringify(updated))
    window.dispatchEvent(new Event('cartUpdated'))
  }

  const handleUpdateQuantity = (eventId, newQuantity) => {
    if (newQuantity < 1) return
    
    const updated = cartItems.map(item =>
      item.event_id === eventId ? { ...item, quantity: newQuantity } : item
    )
    setCartItems(updated)
    localStorage.setItem('cart', JSON.stringify(updated))
    window.dispatchEvent(new Event('cartUpdated'))
  }

  const handleClearCart = () => {
    if (window.confirm('Clear entire cart?')) {
      setCartItems([])
      localStorage.removeItem('cart')
      window.dispatchEvent(new Event('cartUpdated'))
    }
  }

  const handleCheckout = async () => {
    setLoading(true)
    setMessage('')

    try {
      const userId = await getOrCreateUser()
      let lastBooking = null

      // Process each cart item
      for (const item of cartItems) {
        const { booking, error } = await createBooking({
          user_id: userId,
          event_id: item.event_id,
          quantity: item.quantity
        })

        if (error) {
          setMessage(`✗ Error booking ${item.title}: ${error}`)
          setLoading(false)
          return
        }

        lastBooking = booking
      }

      setMessage(`✓ All bookings confirmed! Last Booking ID: #${lastBooking.booking_id}`)
      setCartItems([])
      localStorage.removeItem('cart')
      
      // Trigger custom event to update navbar badge
      window.dispatchEvent(new Event('cartUpdated'))
      
      setTimeout(() => {
        navigate(`/booking-confirmation/${lastBooking.booking_id}`)
      }, 1500)
    } catch (error) {
      setMessage('Checkout failed. Try again.')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0)
  const totalPrice = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0)

  return (
    <div className="bg-gray-950 min-h-screen text-white">
      <Navbar />

      <div className="px-4 md:px-10 py-10 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-5xl font-bold mb-2">🛒 Shopping Cart</h1>
          <p className="text-gray-400 text-lg">Review your items before checkout</p>
        </div>

        {/* Success/Error Message */}
        {message && (
          <div className={`mb-8 p-4 rounded-lg text-center font-semibold ${message.includes('✓') ? 'bg-green-900 border border-green-700' : 'bg-red-900 border border-red-700'}`}>
            {message}
          </div>
        )}

        {cartItems.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items Section */}
            <div className="lg:col-span-2">
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <div key={item.event_id} className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-purple-500 transition">
                    <div className="flex gap-6">
                      {/* Image */}
                      <div className="shrink-0">
                        <img
                          src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f"
                          alt={item.title}
                          className="w-28 h-28 rounded-lg object-cover"
                        />
                      </div>

                      {/* Details */}
                      <div className="flex-1">
                        <h3 className="text-xl font-bold mb-1">{item.title}</h3>
                        <p className="text-gray-400 text-sm mb-3">📍 {item.venue}</p>
                        
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-gray-500 text-sm">Unit Price</p>
                            <p className="text-lg font-semibold text-purple-400">Rs. {item.price}</p>
                          </div>

                          {/* Quantity Selector */}
                          <div className="flex items-center gap-3 bg-gray-800 p-2 rounded-lg">
                            <button
                              onClick={() => handleUpdateQuantity(item.event_id, item.quantity - 1)}
                              className="w-8 h-8 flex items-center justify-center bg-gray-700 hover:bg-gray-600 rounded transition"
                            >
                              −
                            </button>
                            <span className="w-8 text-center font-semibold">{item.quantity}</span>
                            <button
                              onClick={() => handleUpdateQuantity(item.event_id, item.quantity + 1)}
                              className="w-8 h-8 flex items-center justify-center bg-gray-700 hover:bg-gray-600 rounded transition"
                            >
                              +
                            </button>
                          </div>

                          {/* Subtotal */}
                          <div className="text-right">
                            <p className="text-gray-500 text-sm">Subtotal</p>
                            <p className="text-xl font-bold text-purple-400">Rs. {item.price * item.quantity}</p>
                          </div>
                        </div>
                      </div>

                      {/* Remove Button */}
                      <button
                        onClick={() => handleRemoveFromCart(item.event_id)}
                        className="shrink-0 text-2xl text-gray-500 hover:text-red-400 transition"
                        title="Remove from cart"
                      >
                        ✕
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Clear Cart Button */}
              <button
                onClick={handleClearCart}
                className="mt-6 w-full px-4 py-3 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg transition font-semibold"
              >
                Clear All Items
              </button>
            </div>

            {/* Order Summary Sidebar */}
            <div className="lg:col-span-1">
              <div className="bg-linear-to-br from-purple-900 to-purple-800 border border-purple-700 rounded-2xl p-8 sticky top-24">
                <h2 className="text-2xl font-bold mb-8 text-center">Order Summary</h2>

                {/* Items Count */}
                <div className="space-y-4 mb-6 pb-6 border-b border-purple-700">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-200">Items</span>
                    <span className="text-xl font-bold">{totalItems}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-200">Events</span>
                    <span className="text-xl font-bold">{cartItems.length}</span>
                  </div>
                </div>

                {/* Price Breakdown */}
                <div className="bg-gray-900 bg-opacity-50 rounded-lg p-4 mb-6">
                  <div className="flex justify-between mb-3">
                    <span className="text-gray-300">Subtotal</span>
                    <span className="font-semibold">Rs. {totalPrice}</span>
                  </div>
                  <div className="flex justify-between mb-3">
                    <span className="text-gray-300">Tax (0%)</span>
                    <span className="font-semibold">Rs. 0</span>
                  </div>
                  <div className="flex justify-between mb-3">
                    <span className="text-gray-300">Delivery</span>
                    <span className="font-semibold">Free</span>
                  </div>
                  <div className="border-t border-gray-700 pt-3 flex justify-between">
                    <span className="text-gray-200 font-semibold">Total</span>
                    <span className="text-2xl font-bold text-white">Rs. {totalPrice}</span>
                  </div>
                </div>

                {/* Checkout Button */}
                <button
                  onClick={handleCheckout}
                  disabled={loading}
                  className="w-full bg-white text-purple-600 py-4 rounded-lg hover:bg-gray-100 transition font-bold text-lg disabled:opacity-50 mb-3"
                >
                  {loading ? '⏳ Processing...' : '✓ Confirm Checkout'}
                </button>

                {/* Trust Badge */}
                <div className="text-center text-sm text-gray-300 flex items-center justify-center gap-2">
                  <span>🔒</span>
                  <span>Secure Payment</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          // Empty Cart
          <div className="text-center py-24">
            <div className="text-6xl mb-4">🛒</div>
            <p className="text-3xl font-bold mb-2">Your cart is empty</p>
            <p className="text-gray-400 text-lg mb-8">Add some events to get started</p>
            <button
              onClick={() => navigate('/events')}
              className="px-8 py-4 bg-purple-600 hover:bg-purple-700 rounded-lg font-bold text-lg transition inline-block"
            >
              Continue Shopping
            </button>
          </div>
        )}
      </div>

      <Footer />
    </div>
  )
}

export default Cart

