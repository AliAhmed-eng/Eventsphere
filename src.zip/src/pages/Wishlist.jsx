import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
// Wishlist uses localStorage; Supabase table may not exist
import RatingStars from '../components/RatingStars'
import { reviewsService } from '../services/reviews'

function Wishlist() {
  const [wishlistItems, setWishlistItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [userId, setUserId] = useState(null)
  const [message, setMessage] = useState('')
  const [eventRatings, setEventRatings] = useState({})
  const navigate = useNavigate()

  useEffect(() => {
    // Ensure user_id exists
    const id = localStorage.getItem('user_id') || '1'
    localStorage.setItem('user_id', id)
    setUserId(id)
    loadWishlist(id)

    window.addEventListener('wishlistUpdated', () => loadWishlist(id))
    return () => {
      window.removeEventListener('wishlistUpdated', () => loadWishlist(id))
    }
  }, [])

  async function loadWishlist(userId) {
    try {
      // Load from localStorage instead of Supabase
      const wishlistKey = `wishlist_${userId}`
      const wishlistData = JSON.parse(localStorage.getItem(wishlistKey) || '[]')
      
      if (wishlistData && wishlistData.length > 0) {
        setWishlistItems(wishlistData)
        
        // Load ratings for each item
        for (const item of wishlistData) {
          const { averageRating, totalReviews } = await reviewsService.getEventRating(item.event_id)
          setEventRatings(prev => ({
            ...prev,
            [item.event_id]: { averageRating, totalReviews }
          }))
        }
      } else {
        // No items in wishlist
        setWishlistItems([])
      }
    } catch (error) {
      console.error('Error loading wishlist:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleRemoveFromWishlist = async (eventId) => {
    try {
      const wishlistKey = `wishlist_${userId}`
      let wishlistData = JSON.parse(localStorage.getItem(wishlistKey) || '[]')
      wishlistData = wishlistData.filter(item => item.event_id !== eventId)
      localStorage.setItem(wishlistKey, JSON.stringify(wishlistData))
      
      setMessage('✓ Removed from wishlist')
      loadWishlist(userId)
      window.dispatchEvent(new Event('wishlistUpdated'))
      setTimeout(() => setMessage(''), 2000)
    } catch (error) {
      console.error('Error removing from wishlist:', error)
    }
  }

  const handleAddToCart = (item) => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]')
    
    const exists = cart.some(c => c.event_id === item.event_id)
    if (!exists) {
      cart.push({
        ...item,
        quantity: 1
      })
      localStorage.setItem('cart', JSON.stringify(cart))
      setMessage('✓ Added to cart')
      window.dispatchEvent(new Event('cartUpdated'))
      setTimeout(() => setMessage(''), 2000)
    } else {
      setMessage('Already in cart')
      setTimeout(() => setMessage(''), 2000)
    }
  }

  const handleClearWishlist = async () => {
    if (!window.confirm('Clear entire wishlist?')) return

    try {
      const wishlistKey = `wishlist_${userId}`
      localStorage.setItem(wishlistKey, JSON.stringify([]))
      setWishlistItems([])
      setMessage('✓ Wishlist cleared')
      window.dispatchEvent(new Event('wishlistUpdated'))
      setTimeout(() => setMessage(''), 2000)
    } catch (error) {
      console.error('Error clearing wishlist:', error)
    }
  }

  if (loading) {
    return (
      <div className="bg-gray-950 min-h-screen text-white">
        <Navbar />
        <div className="flex items-center justify-center py-20">
          <p className="text-2xl">Loading...</p>
        </div>
        <Footer />
      </div>
    )
  }

  if (!userId) {
    return (
      <div className="bg-gray-950 min-h-screen text-white flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center bg-gray-900 p-12 rounded-2xl max-w-md">
            <p className="text-6xl mb-4">❤️</p>
            <p className="text-2xl font-bold mb-4">Login Required</p>
            <p className="text-gray-300 mb-8">Login to save your favorite events</p>
            <button
              onClick={() => navigate('/')}
              className="w-full px-6 py-3 bg-purple-600 rounded-lg hover:bg-purple-700 font-semibold"
            >
              Go to Login
            </button>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="bg-gray-950 min-h-screen text-white">
      <Navbar />

      <div className="px-4 md:px-10 py-10 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-5xl font-bold mb-2">❤️ My Wishlist</h1>
          <p className="text-gray-400 text-lg">Your saved favorite events</p>
        </div>

        {/* Message */}
        {message && (
          <div className={`mb-8 p-4 rounded-lg text-center font-semibold ${message.includes('✓') ? 'bg-green-900 border border-green-700' : 'bg-red-900 border border-red-700'}`}>
            {message}
          </div>
        )}

        {wishlistItems.length > 0 ? (
          <>
            <div className="space-y-4 mb-8">
              {wishlistItems.map((item) => (
                <div
                  key={item.wishlist_id}
                  className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-purple-500 transition"
                >
                  <div className="flex gap-6">
                    {/* Image */}
                    <div className="flex-shrink-0">
                      <img
                        src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f"
                        alt={item.events?.title}
                        className="w-32 h-32 rounded-lg object-cover cursor-pointer hover:scale-105 transition"
                        onClick={() => navigate(`/events/${item.event_id}`)}
                      />
                    </div>

                    {/* Details */}
                    <div className="flex-1">
                      <h3
                        className="text-2xl font-bold mb-2 cursor-pointer hover:text-purple-400 transition"
                        onClick={() => navigate(`/events/${item.event_id}`)}
                      >
                        {item.events?.title}
                      </h3>

                      {/* Rating */}
                      {eventRatings[item.event_id]?.totalReviews > 0 && (
                        <div className="flex items-center gap-2 mb-2">
                          <RatingStars rating={eventRatings[item.event_id]?.averageRating || 0} size="sm" />
                          <span className="text-sm text-gray-400">
                            ({eventRatings[item.event_id]?.totalReviews})
                          </span>
                        </div>
                      )}

                      <p className="text-gray-400 text-sm mb-1">📍 {item.events?.venue}</p>
                      <p className="text-gray-400 text-sm mb-3">📅 {item.events?.event_date}</p>

                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-gray-500 text-sm">Price</p>
                          <p className="text-2xl font-semibold text-purple-400">Rs. {item.events?.price}</p>
                        </div>

                        <div>
                          <p className="text-gray-500 text-sm">Available Seats</p>
                          <p className={`text-lg font-semibold ${item.events?.available_seats > 10 ? 'text-green-400' : 'text-orange-400'}`}>
                            {item.events?.available_seats}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col gap-3 justify-start">
                      <button
                        onClick={() => navigate(`/events/${item.event_id}`)}
                        className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition font-semibold whitespace-nowrap"
                      >
                        View Details
                      </button>
                      <button
                        onClick={() => handleAddToCart(item)}
                        className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition font-semibold whitespace-nowrap"
                      >
                        Add to Cart
                      </button>
                      <button
                        onClick={() => handleRemoveFromWishlist(item.event_id)}
                        className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition font-semibold whitespace-nowrap"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Summary and Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gray-900 p-6 rounded-lg">
                <p className="text-gray-400 mb-2">Total Items in Wishlist</p>
                <p className="text-4xl font-bold text-purple-400">{wishlistItems.length}</p>
              </div>

              <div className="bg-gray-900 p-6 rounded-lg flex items-end">
                <button
                  onClick={handleClearWishlist}
                  className="w-full px-6 py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg transition font-semibold"
                >
                  Clear All Items
                </button>
              </div>
            </div>
          </>
        ) : (
          // Empty Wishlist
          <div className="text-center py-24">
            <div className="text-6xl mb-4">❤️</div>
            <p className="text-3xl font-bold mb-2">Your wishlist is empty</p>
            <p className="text-gray-400 text-lg mb-8">Save your favorite events to view them later</p>
            <button
              onClick={() => navigate('/events')}
              className="px-8 py-4 bg-purple-600 hover:bg-purple-700 rounded-lg font-bold text-lg transition inline-block"
            >
              Browse Events
            </button>
          </div>
        )}
      </div>

      <Footer />
    </div>
  )
}

export default Wishlist
