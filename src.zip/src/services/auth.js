import { supabase } from "./supabase";

/**
 * LOGIN USER (FIXED)
 */
export async function loginUser(email, password) {
  try {
    const cleanEmail = email.trim().toLowerCase();
    const cleanPassword = password.trim();

    const { data, error } = await supabase
      .from("users")
      .select("*")
      .eq("email", cleanEmail)
      .maybeSingle(); // ✅ FIXED (no crash)

    if (error || !data) {
      return { user: null, error: "User not found" };
    }

    if (data.password !== cleanPassword) {
      return { user: null, error: "Wrong password" };
    }

    localStorage.setItem("current_user", JSON.stringify(data));

    return { user: data, error: null };
  } catch (err) {
    console.error("Login error:", err.message);
    return { user: null, error: "Login failed" };
  }
}

/**
 * REGISTER USER (FIXED)
 */
export async function registerUser(name, email, phone, password) {
  try {
    const cleanEmail = email.trim().toLowerCase();

    const { data: existingUser } = await supabase
      .from("users")
      .select("user_id")
      .eq("email", cleanEmail)
      .maybeSingle();

    if (existingUser) {
      return { user: null, error: "Email already registered" };
    }

    const { data, error } = await supabase
      .from("users")
      .insert([
        {
          name: name.trim(),
          email: cleanEmail,
          phone: phone.trim(),
          password: password.trim(),
        },
      ])
      .select()
      .single();

    if (error) {
      return { user: null, error: error.message };
    }

    localStorage.setItem("current_user", JSON.stringify(data));

    return { user: data, error: null };
  } catch (err) {
    console.error("Register error:", err.message);
    return { user: null, error: "Registration failed" };
  }
}

/**
 * GET USER
 */
export async function getUserById(userId) {
  const { data } = await supabase
    .from("users")
    .select("*")
    .eq("user_id", userId)
    .single();

  return data || null;
}

/**
 * UPDATE USER
 */
export async function updateUserProfile(userId, updates) {
  const { data, error } = await supabase
    .from("users")
    .update(updates)
    .eq("user_id", userId)
    .select()
    .single();

  if (error) return { user: null, error: error.message };

  localStorage.setItem("current_user", JSON.stringify(data));

  return { user: data, error: null };
}

/**
 * CURRENT USER
 */
export function getCurrentUser() {
  return JSON.parse(localStorage.getItem("current_user"));
}

/**
 * LOGOUT
 */
export function logoutUser() {
  localStorage.removeItem("current_user");
}

/**
 * GUEST USER (FIXED)
 */
export async function getOrCreateUser() {
  const existing = getCurrentUser();

  if (existing?.user_id) {
    return existing.user_id;
  }

  const guestEmail = `guest_${Date.now()}@guest.com`;

  const { data, error } = await supabase
    .from("users")
    .insert([
      {
        name: "Guest User",
        email: guestEmail,
        phone: "0000000000",
        password: "guest123",
      },
    ])
    .select()
    .single();

  if (error) {
    console.error(error);
    return null;
  }

  localStorage.setItem("current_user", JSON.stringify(data));

  return data.user_id;
}