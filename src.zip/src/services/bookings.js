import { supabase } from "./supabase";
import { decreaseAvailableSeats, increaseAvailableSeats } from "./events";

/**
 * Create new booking
 * Schema: booking_id, user_id, event_id, quantity, booking_date
 */
export async function createBooking(bookingData) {
  try {
    const quantity = bookingData.quantity || 1;

    // 1. Create booking (insert one record with num_tickets count)
    const { data: newBooking, error: bookingError } = await supabase
      .from("bookings")
      .insert([
        {
          user_id: bookingData.user_id,
          event_id: bookingData.event_id,
          quantity: quantity
        }
      ])
      .select()
      .single();

    if (bookingError) {
      return { booking: null, error: bookingError.message };
    }

    // 2. Decrease available seats
    const decreaseResult = await decreaseAvailableSeats(
      bookingData.event_id,
      quantity
    );

    if (!decreaseResult.success) {
      // Rollback booking if seats update failed
      await supabase.from("bookings").delete().eq("booking_id", newBooking.booking_id);
      return { booking: null, error: "Failed to update event seats" };
    }

    return { booking: newBooking, error: null };
  } catch (err) {
    console.error("Create booking error:", err.message);
    return { booking: null, error: "Booking failed. Please try again." };
  }
}

/**
 * Get user bookings
 */
export async function getUserBookings(userId) {
  try {
    const { data, error } = await supabase
      .from("bookings")
      .select(`
        *,
        events (
          event_id,
          title,
          venue,
          event_date,
          price,
          image_url,
          event_organizers (
            organizers (name, email)
          )
        )
      `)
      .eq("user_id", userId)
      .order("booking_date", { ascending: false });

    if (error) {
      console.error("Get bookings error:", error);
      return [];
    }

    return data || [];
  } catch (err) {
    console.error("Get user bookings error:", err.message);
    return [];
  }
}

/**
 * Get booking by ID
 */
export async function getBookingById(bookingId) {
  try {
    const { data, error } = await supabase
      .from("bookings")
      .select(`
        *,
        events (
          *,
          event_organizers (
            organizers (*)
          )
        ),
        users (*)
      `)
      .eq("booking_id", bookingId)
      .single();

    if (error) {
      console.error("Get booking error:", error);
      return null;
    }

    return data;
  } catch (err) {
    console.error("Get booking by ID error:", err.message);
    return null;
  }
}

/**
 * Cancel booking - deletes the booking and restores seats
 */
export async function cancelBooking(bookingId, eventId, quantity) {
  try {
    // 1. Delete the booking
    const { error: deleteError } = await supabase
      .from("bookings")
      .delete()
      .eq("booking_id", bookingId);

    if (deleteError) {
      return { success: false, error: deleteError.message };
    }

    // 2. Increase available seats
    const increaseResult = await increaseAvailableSeats(eventId, quantity);

    if (!increaseResult.success) {
      return { success: false, error: "Failed to update seats" };
    }

    return { success: true };
  } catch (err) {
    console.error("Cancel booking error:", err.message);
    return { success: false, error: "Failed to cancel booking" };
  }
}

/**
 * Get event bookings (for organizer)
 */
export async function getEventBookings(eventId) {
  try {
    const { data, error } = await supabase
      .from("bookings")
      .select(`
        *,
        users (user_id, name, email, phone)
      `)
      .eq("event_id", eventId)
      .order("booking_date", { ascending: false });

    if (error) {
      return [];
    }

    return data || [];
  } catch (err) {
    console.error("Get event bookings error:", err.message);
    return [];
  }
}

/**
 * Check if user has booked an event
 */
export async function hasUserBookedEvent(userId, eventId) {
  try {
    const { data, error } = await supabase
      .from("bookings")
      .select("booking_id")
      .eq("user_id", userId)
      .eq("event_id", eventId)
      .single();

    if (error) {
      return false;
    }

    return !!data;
  } catch (err) {
    return false;
  }
}