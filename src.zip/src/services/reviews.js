import { supabase } from './supabase'

export const reviewsService = {
  // Fetch all reviews for an event
  async getEventReviews(eventId) {
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select(`
          review_id,
          user_id,
          event_id,
          rating,
          comment,
          created_at,
          users (
            user_id,
            name,
            email
          )
        `)
        .eq('event_id', eventId)
        .order('created_at', { ascending: false })

      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error fetching reviews:', error)
      return []
    }
  },

  // Get average rating for an event
  async getEventRating(eventId) {
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('rating')
        .eq('event_id', eventId)

      if (error) throw error
      
      if (!data || data.length === 0) {
        return { averageRating: 0, totalReviews: 0 }
      }

      const sum = data.reduce((acc, curr) => acc + curr.rating, 0)
      const averageRating = (sum / data.length).toFixed(1)

      return { averageRating: parseFloat(averageRating), totalReviews: data.length }
    } catch (error) {
      console.error('Error calculating rating:', error)
      return { averageRating: 0, totalReviews: 0 }
    }
  },

  // Add a review
  async addReview(userId, eventId, rating, comment) {
    try {
      const { data, error } = await supabase
        .from('reviews')
        .insert([
          {
            user_id: userId,
            event_id: eventId,
            rating: parseInt(rating),
            comment: comment || ''
          }
        ])
        .select()

      if (error) throw error
      return { success: true, data }
    } catch (error) {
      console.error('Error adding review:', error)
      return { success: false, error: error.message }
    }
  },

  // Update a review
  async updateReview(reviewId, rating, comment) {
    try {
      const { data, error } = await supabase
        .from('reviews')
        .update({
          rating: parseInt(rating),
          comment: comment || ''
        })
        .eq('review_id', reviewId)
        .select()

      if (error) throw error
      return { success: true, data }
    } catch (error) {
      console.error('Error updating review:', error)
      return { success: false, error: error.message }
    }
  },

  // Delete a review
  async deleteReview(reviewId) {
    try {
      const { error } = await supabase
        .from('reviews')
        .delete()
        .eq('review_id', reviewId)

      if (error) throw error
      return { success: true }
    } catch (error) {
      console.error('Error deleting review:', error)
      return { success: false, error: error.message }
    }
  },

  // Check if user has reviewed this event
  async getUserReview(userId, eventId) {
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('*')
        .eq('user_id', userId)
        .eq('event_id', eventId)
        .single()

      if (error?.code === 'PGRST116') return null
      if (error) throw error
      return data
    } catch (error) {
      console.error('Error fetching user review:', error)
      return null
    }
  }
}
